#!/bin/bash

echo $1
play $1 tempo 0.9 pitch 200 treble -20
