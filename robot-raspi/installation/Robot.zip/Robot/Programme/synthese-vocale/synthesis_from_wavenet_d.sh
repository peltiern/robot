#!/bin/bash

echo $1
play $1 pitch 900 treble -4 gain 3
