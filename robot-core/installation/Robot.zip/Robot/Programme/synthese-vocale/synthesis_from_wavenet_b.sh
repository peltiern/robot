#!/bin/bash

echo $1
play $1 tempo 0.85 pitch 800 treble -8 gain 5
