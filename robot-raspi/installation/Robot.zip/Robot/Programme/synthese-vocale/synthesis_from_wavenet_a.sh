#!/bin/bash

echo $1
play $1 stretch 1.1 pitch 350 treble -10
