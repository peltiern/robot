#!/bin/bash

echo $1

play $1 stretch 1.05 pitch 450 treble 3
#play $1 stretch 1.1 pitch 550 treble 3 tremolo 5000 60
